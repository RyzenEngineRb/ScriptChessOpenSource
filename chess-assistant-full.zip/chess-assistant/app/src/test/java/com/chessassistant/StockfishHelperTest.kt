package com.chessassistant

import org.junit.Assert.*
import org.junit.Test

class StockfishHelperTest {

    @Test
    fun `uci move format converts correctly`() {
        // e2e4 должен стать "e2 → e4"
        val uci = "e2e4"
        val arrow = "${uci.substring(0, 2)} → ${uci.substring(2, 4)}"
        assertEquals("e2 → e4", arrow)
    }

    @Test
    fun `score formatting positive`() {
        val cp = 50
        val formatted = if (cp >= 0) "+%.1f".format(cp / 100.0) else "%.1f".format(cp / 100.0)
        assertEquals("+0.5", formatted)
    }

    @Test
    fun `score formatting negative`() {
        val cp = -120
        val formatted = if (cp >= 0) "+%.1f".format(cp / 100.0) else "%.1f".format(cp / 100.0)
        assertEquals("-1.2", formatted)
    }
}
