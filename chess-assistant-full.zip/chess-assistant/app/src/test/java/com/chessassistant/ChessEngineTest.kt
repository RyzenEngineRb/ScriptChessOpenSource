package com.chessassistant

import com.chessassistant.engine.ChessEngine
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class ChessEngineTest {

    private lateinit var engine: ChessEngine

    @Before
    fun setUp() {
        engine = ChessEngine()
    }

    @Test
    fun `initial FEN is correct`() {
        val fen = engine.getFen()
        assertTrue("FEN should start with starting position",
            fen.startsWith("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"))
    }

    @Test
    fun `move history is empty on start`() {
        assertTrue(engine.getMoveHistory().isEmpty())
    }

    @Test
    fun `getBestMove returns non-empty string`() {
        val move = engine.getBestMove()
        assertTrue("Best move should not be empty", move.isNotEmpty())
        assertTrue("Best move should contain arrow", move.contains("→"))
    }

    @Test
    fun `reset restores initial state`() {
        engine.getBestMove() // trigger internal state changes
        engine.reset()
        val fen = engine.getFen()
        assertTrue(fen.startsWith("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"))
        assertTrue(engine.getMoveHistory().isEmpty())
    }
}
