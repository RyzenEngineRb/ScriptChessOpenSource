package com.chessassistant

import org.junit.Assert.*
import org.junit.Test

class KeyManagerTest {

    private val validKey = "Unfly---Reborn---Fest8294810Mjk"

    @Test
    fun `valid key passes check`() {
        assertEquals(validKey, "Unfly---Reborn---Fest8294810Mjk")
    }

    @Test
    fun `invalid key fails check`() {
        assertNotEquals("wrongkey123", validKey)
    }

    @Test
    fun `empty key fails check`() {
        assertNotEquals("", validKey)
    }
}
