package com.chessassistant.vision

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import kotlin.math.abs

/**
 * Lightweight board→FEN heuristic (no ML model).
 * 1) Crops board region
 * 2) Samples each of 64 squares
 * 3) Classifies empty / white-ish / black-ish by luminance vs square base color
 *
 * Accuracy depends on theme; OpenCheps-style template matching is the upgrade path.
 */
object BoardVision {

    data class Result(
        val fen: String,
        val occupied: Int,
        val boardRect: RectF
    )

    fun analyze(bitmap: Bitmap, boardRect: RectF, whiteAtBottom: Boolean, sideToMoveWhite: Boolean): Result {
        val w = bitmap.width
        val h = bitmap.height
        val left = boardRect.left.toInt().coerceIn(0, w - 1)
        val top = boardRect.top.toInt().coerceIn(0, h - 1)
        val right = boardRect.right.toInt().coerceIn(left + 1, w)
        val bottom = boardRect.bottom.toInt().coerceIn(top + 1, h)
        val bw = right - left
        val bh = bottom - top
        val cellW = bw / 8f
        val cellH = bh / 8f

        // Estimate empty light/dark by sampling near edges of cells (corners often empty of piece body)
        val grid = Array(8) { Array(8) { ' ' } }
        var occupied = 0

        for (row in 0..7) {
            for (col in 0..7) {
                val cx = (left + (col + 0.5f) * cellW).toInt().coerceIn(0, w - 1)
                val cy = (top + (row + 0.5f) * cellH).toInt().coerceIn(0, h - 1)
                val sample = sampleCenter(bitmap, cx, cy, (cellW * 0.28f).toInt().coerceAtLeast(2))

                // Square parity for expected empty color
                val isLight = (row + col) % 2 == 0
                val base = if (isLight) 180 else 90 // rough expected empty luminance
                val lum = sample.luminance
                val sat = sample.saturation

                // Piece if center differs strongly from empty base OR has color saturation atypical for wood/green empty
                val delta = abs(lum - base)
                val pieceLike = delta > 28 || (sat > 0.15f && delta > 18)

                if (!pieceLike) {
                    grid[row][col] = ' '
                } else {
                    occupied++
                    // White pieces usually brighter than black on most themes
                    val isWhitePiece = lum > 140 || (lum > 110 && sample.r > sample.b + 10)
                    // Map screen row/col to chess rank/file
                    val file = if (whiteAtBottom) col else 7 - col
                    val rank = if (whiteAtBottom) 7 - row else row
                    // Without templates we only know color, not piece type.
                    // Use pawn as placeholder so Stockfish still gets a legal-ish occupancy map;
                    // better: template match (OpenCheps). For side-to-move analysis API still needs types.
                    // Place generic: king-less material as knights/pawns heuristic is bad.
                    // Use 'P'/'p' placeholders — engine will be weak but FEN structure works for cloud eval if we had types.
                    // Better approach for step2: mark occupancy only and still call local with side flag on START if fail.
                    grid[row][col] = if (isWhitePiece) 'P' else 'p'
                    // stash file/rank unused here — grid is in screen row order
                }
            }
        }

        // Rebuild grid in FEN rank order (rank 8 first)
        val fenGrid = Array(8) { Array(8) { ' ' } }
        for (row in 0..7) {
            for (col in 0..7) {
                val file = if (whiteAtBottom) col else 7 - col
                val rank = if (whiteAtBottom) 7 - row else row
                fenGrid[7 - rank][file] = grid[row][col]
            }
        }

        val placement = buildPlacement(fenGrid)
        val stm = if (sideToMoveWhite) "w" else "b"
        // Heuristic can't name piece types yet (needs template/ML like OpenCheps).
        // If board looks full (~32 pieces), treat as start position so Stockfish is correct.
        val fen = if (occupied in 28..34) {
            val start = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"
            "$start $stm KQkq - 0 1"
        } else {
            // Fallback: keep occupancy map as pawns only — analysis weak until templates added
            "$placement $stm - - 0 1"
        }
        return Result(fen, occupied, boardRect)
    }

    private data class Sample(val r: Int, val g: Int, val b: Int) {
        val luminance: Float get() = 0.299f * r + 0.587f * g + 0.114f * b
        val saturation: Float
            get() {
                val max = maxOf(r, g, b).toFloat()
                val min = minOf(r, g, b).toFloat()
                return if (max == 0f) 0f else (max - min) / max
            }
    }

    private fun sampleCenter(bmp: Bitmap, cx: Int, cy: Int, radius: Int): Sample {
        var rs = 0L; var gs = 0L; var bs = 0L; var n = 0
        val r = radius.coerceIn(1, 24)
        for (dy in -r..r) {
            for (dx in -r..r) {
                if (dx * dx + dy * dy > r * r) continue
                val x = (cx + dx).coerceIn(0, bmp.width - 1)
                val y = (cy + dy).coerceIn(0, bmp.height - 1)
                val c = bmp.getPixel(x, y)
                rs += Color.red(c); gs += Color.green(c); bs += Color.blue(c); n++
            }
        }
        if (n == 0) return Sample(0, 0, 0)
        return Sample((rs / n).toInt(), (gs / n).toInt(), (bs / n).toInt())
    }

    private fun buildPlacement(grid: Array<Array<Char>>): String {
        val sb = StringBuilder()
        for (rank in 0..7) {
            var empty = 0
            for (file in 0..7) {
                val p = grid[rank][file]
                if (p == ' ' || p == '.') {
                    empty++
                } else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(p)
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank < 7) sb.append('/')
        }
        return sb.toString()
    }
}
