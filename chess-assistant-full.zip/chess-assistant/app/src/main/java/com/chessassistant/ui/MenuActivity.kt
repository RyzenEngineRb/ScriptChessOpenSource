package com.chessassistant.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.chessassistant.databinding.ActivityMenuBinding
import com.chessassistant.overlay.OverlayService
import com.chessassistant.utils.KeyManager

/**
 * Дополнительное меню приложения.
 * Открывается через нотификацию оверлея.
 */
class MenuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMenuBinding
    private val keyManager by lazy { KeyManager(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupMenu()
    }

    private fun setupMenu() {
        // Запустить/остановить оверлей
        binding.btnToggleOverlay.setOnClickListener {
            val serviceIntent = Intent(this, OverlayService::class.java)
            if (OverlayService.isRunning) {
                stopService(serviceIntent)
                binding.btnToggleOverlay.text = "Enable Overlay"
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    startForegroundService(serviceIntent)
                else
                    startService(serviceIntent)
                binding.btnToggleOverlay.text = "Disable Overlay"
            }
        }

        // Сбросить ключ
        binding.btnResetKey.setOnClickListener {
            keyManager.clearKey()
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

        // Закрыть
        binding.btnClose.setOnClickListener { finish() }

        // Статус оверлея
        binding.tvOverlayStatus.text = if (OverlayService.isRunning) "● Active" else "○ Inactive"
    }
}
