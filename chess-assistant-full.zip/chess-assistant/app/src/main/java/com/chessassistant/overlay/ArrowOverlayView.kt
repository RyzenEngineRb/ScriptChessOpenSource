package com.chessassistant.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Full-screen transparent view that draws thin cyan arrows for suggested moves.
 */
class ArrowOverlayView(context: Context) : View(context) {

    data class Arrow(val from: PointF, val to: PointF)

    private val arrows = mutableListOf<Arrow>()

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 100, 180, 255) // soft blue
        style = Paint.Style.STROKE
        strokeWidth = 4.5f * resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 100, 180, 255)
        style = Paint.Style.FILL
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 100, 180, 255)
        style = Paint.Style.STROKE
        strokeWidth = 10f * resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
    }

    fun setArrows(list: List<Arrow>) {
        arrows.clear()
        arrows.addAll(list)
        invalidate()
    }

    fun clearArrows() {
        arrows.clear()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (a in arrows) {
            drawArrow(canvas, a.from, a.to)
        }
    }

    private fun drawArrow(canvas: Canvas, from: PointF, to: PointF) {
        // Shorten ends so arrow doesn't cover piece centers fully
        val dx = to.x - from.x
        val dy = to.y - from.y
        val len = kotlin.math.hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(1f)
        val inset = 12f * resources.displayMetrics.density
        val sx = from.x + dx / len * inset
        val sy = from.y + dy / len * inset
        val ex = to.x - dx / len * inset
        val ey = to.y - dy / len * inset

        canvas.drawLine(sx, sy, ex, ey, glowPaint)
        canvas.drawLine(sx, sy, ex, ey, linePaint)

        // Arrow head
        val angle = atan2((ey - sy).toDouble(), (ex - sx).toDouble())
        val headLen = 16f * resources.displayMetrics.density
        val headAngle = Math.PI / 7.0
        val path = Path()
        path.moveTo(ex, ey)
        path.lineTo(
            (ex - headLen * cos(angle - headAngle)).toFloat(),
            (ey - headLen * sin(angle - headAngle)).toFloat()
        )
        path.lineTo(
            (ex - headLen * cos(angle + headAngle)).toFloat(),
            (ey - headLen * sin(angle + headAngle)).toFloat()
        )
        path.close()
        canvas.drawPath(path, headPaint)
    }
}
