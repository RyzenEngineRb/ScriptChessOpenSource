package com.chessassistant.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Проверяет наличие новой версии через GitHub Releases API.
 * Repo: поменяй YOUR_GITHUB_USER / chess-assistant на свои данные.
 */
object AppUpdateChecker {

    private const val RELEASES_URL =
        "https://api.github.com/repos/YOUR_GITHUB_USER/chess-assistant/releases/latest"

    data class UpdateInfo(
        val latestVersion: String,
        val downloadUrl: String,
        val releaseNotes: String
    )

    suspend fun checkForUpdate(currentVersion: String): UpdateInfo? =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = URL(RELEASES_URL)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 5000
                    readTimeout = 5000
                    setRequestProperty("Accept", "application/vnd.github.v3+json")
                }

                if (conn.responseCode != 200) return@runCatching null

                val body = conn.inputStream.bufferedReader().readText()
                conn.disconnect()

                val json = JSONObject(body)
                val tag = json.getString("tag_name").trimStart('v')
                val notes = json.optString("body", "")
                val assets = json.getJSONArray("assets")
                val downloadUrl = if (assets.length() > 0)
                    assets.getJSONObject(0).getString("browser_download_url")
                else json.getString("html_url")

                if (isNewer(tag, currentVersion)) {
                    UpdateInfo(tag, downloadUrl, notes)
                } else null
            }.getOrNull()
        }

    /** Простое сравнение версий: "1.1.0" > "1.0.0" */
    private fun isNewer(remote: String, local: String): Boolean {
        fun parts(v: String) = v.split(".").map { it.toIntOrNull() ?: 0 }
        val r = parts(remote); val l = parts(local)
        for (i in 0 until maxOf(r.size, l.size)) {
            val rv = r.getOrElse(i) { 0 }; val lv = l.getOrElse(i) { 0 }
            if (rv > lv) return true
            if (rv < lv) return false
        }
        return false
    }
}
