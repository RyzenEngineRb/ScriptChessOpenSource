package com.chessassistant.vision

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/**
 * Holds MediaProjection and grabs a single full-screen bitmap.
 */
class ScreenCaptureHelper(private val context: Context) {

    companion object {
        private const val TAG = "ScreenCapture"
        @Volatile var latestProjection: MediaProjection? = null
        @Volatile var resultCode: Int = 0
        @Volatile var resultData: Intent? = null

        fun hasProjection(): Boolean = latestProjection != null || resultData != null
    }

    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped")
            release()
            latestProjection = null
        }
    }

    fun attachFromResult(code: Int, data: Intent) {
        resultCode = code
        resultData = data
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        try {
            latestProjection?.unregisterCallback(projectionCallback)
            latestProjection?.stop()
        } catch (_: Exception) {}
        val proj = mgr.getMediaProjection(code, data)
        proj.registerCallback(projectionCallback, mainHandler)
        latestProjection = proj
    }

    fun captureOnce(onBitmap: (Bitmap?) -> Unit) {
        val projection = latestProjection
        if (projection == null) {
            // try re-create from stored intent
            val data = resultData
            if (data != null && resultCode != 0) {
                try {
                    attachFromResult(resultCode, data)
                } catch (e: Exception) {
                    Log.e(TAG, "re-attach failed", e)
                    onBitmap(null)
                    return
                }
            } else {
                onBitmap(null)
                return
            }
        }
        val proj = latestProjection ?: run {
            onBitmap(null)
            return
        }
        try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            imageReader?.close()
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            virtualDisplay?.release()
            virtualDisplay = proj.createVirtualDisplay(
                "chess_cap",
                width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader!!.surface, null, null
            )

            mainHandler.postDelayed({
                try {
                    val image = imageReader?.acquireLatestImage()
                    if (image == null) {
                        onBitmap(null)
                        return@postDelayed
                    }
                    val plane = image.planes[0]
                    val buf = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val bmp = Bitmap.createBitmap(
                        width + rowPadding / pixelStride,
                        height,
                        Bitmap.Config.ARGB_8888
                    )
                    bmp.copyPixelsFromBuffer(buf)
                    val cropped = Bitmap.createBitmap(bmp, 0, 0, width, height)
                    if (bmp != cropped) bmp.recycle()
                    image.close()
                    onBitmap(cropped)
                } catch (e: Exception) {
                    Log.e(TAG, "capture failed", e)
                    onBitmap(null)
                }
            }, 400)
        } catch (e: Exception) {
            Log.e(TAG, "setup failed", e)
            onBitmap(null)
        }
    }

    fun release() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        virtualDisplay = null
        imageReader = null
    }
}
