package com.chessassistant.utils

import android.content.Context

/** Who the user is playing as. */
object SidePrefs {
    private const val PREFS = "chess_side_prefs"
    private const val KEY_WHITE = "play_as_white"

    fun playAsWhite(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_WHITE, true)

    fun setPlayAsWhite(ctx: Context, white: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_WHITE, white).apply()
    }
}
