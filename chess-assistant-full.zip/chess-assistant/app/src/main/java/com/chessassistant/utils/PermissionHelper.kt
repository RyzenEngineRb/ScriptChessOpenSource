package com.chessassistant.utils

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast

object PermissionHelper {

    /** Проверяет, есть ли разрешение на overlay */
    fun hasOverlayPermission(activity: Activity): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(activity)
        } else true
    }

    /** Открывает системный экран запроса overlay разрешения */
    fun requestOverlayPermission(activity: Activity, requestCode: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${activity.packageName}")
            )
            activity.startActivityForResult(intent, requestCode)
        }
    }

    /** Показывает объяснение зачем нужно разрешение */
    fun showOverlayRationale(activity: Activity) {
        Toast.makeText(
            activity,
            "Chess Assistant нужно разрешение \"Поверх других окон\" " +
            "чтобы показывать подсказки пока открыт Chess.com",
            Toast.LENGTH_LONG
        ).show()
    }
}
