package com.chessassistant.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.chessassistant.R
import com.chessassistant.databinding.ActivityMainBinding
import com.chessassistant.overlay.OverlayService
import com.chessassistant.utils.KeyManager

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val keyManager by lazy { KeyManager(this) }

    companion object {
        private const val OVERLAY_PERMISSION_REQUEST = 1001
        private const val BATTERY_OPT_REQUEST = 1002
        val CHESS_PACKAGES = listOf(
            "com.chess",
            "com.chess.app",
            "com.chess.chess_com"
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)
            setupUI()
            if (keyManager.isKeyValid()) {
                showUnlocked()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Ошибка запуска: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupUI() {
        binding.btnStartGame.setOnClickListener {
            val enteredKey = binding.etAccessKey.text.toString().trim()
            if (keyManager.isKeyValid() || keyManager.validateAndSave(enteredKey)) {
                checkPermissionsAndLaunch()
            } else {
                binding.etAccessKey.error = "Неверный ключ"
                shake(binding.etAccessKey)
            }
        }
    }

    private fun showUnlocked() {
        binding.etAccessKey.setText("••••••••••••••••••••")
        binding.etAccessKey.isEnabled = false
        binding.btnStartGame.text = getString(R.string.launch_chess)
    }

    /** Цепочка: overlay → battery opt → launch */
    private fun checkPermissionsAndLaunch() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Нужно разрешение «Поверх других окон»", Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST)
            return
        }
        requestBatteryOptimizationThenLaunch()
    }

    private fun requestBatteryOptimizationThenLaunch() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivityForResult(intent, BATTERY_OPT_REQUEST)
                    return
                } catch (e: Exception) {
                    // На части MIUI этот intent недоступен — просто продолжаем
                    e.printStackTrace()
                }
            }
        }
        launchChessCom()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            OVERLAY_PERMISSION_REQUEST -> {
                if (Settings.canDrawOverlays(this)) {
                    requestBatteryOptimizationThenLaunch()
                } else {
                    Toast.makeText(this, "Разрешение на overlay необходимо", Toast.LENGTH_LONG).show()
                }
            }
            BATTERY_OPT_REQUEST -> {
                // В любом случае продолжаем — пользователь мог отказаться
                launchChessCom()
            }
        }
    }

    private fun launchChessCom() {
        // 1. Старт сервиса
        try {
            val serviceIntent = Intent(this, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "Overlay запущен", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Ошибка запуска overlay: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }

        // 2. Небольшая пауза, чтобы сервис успел сделать startForeground + addView
        binding.root.postDelayed({
            openChessApp()
        }, 400)
    }

    private fun openChessApp() {
        val pm = packageManager
        var launched = false

        for (pkg in CHESS_PACKAGES) {
            try {
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launchIntent)
                    launched = true
                    break
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        if (!launched) {
            Toast.makeText(this, "Chess.com не найден, открываю Play Store…", Toast.LENGTH_LONG).show()
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.chess"))
                        .apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                )
            } catch (e: Exception) {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=com.chess")
                    )
                )
            }
        }

        // Сворачиваем, но не finish() — чтобы процесс жил
        moveTaskToBack(true)
    }

    private fun shake(view: android.view.View) {
        val anim = android.view.animation.AnimationUtils.loadAnimation(this, R.anim.shake)
        view.startAnimation(anim)
    }
}
