package com.chessassistant.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.chessassistant.R
import com.chessassistant.databinding.ActivityMainBinding
import com.chessassistant.overlay.OverlayService
import com.chessassistant.utils.KeyManager

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val keyManager by lazy { KeyManager(this) }

    companion object {
        private const val OVERLAY_PERMISSION_REQUEST = 1001
        // Пакет Chess.com
        const val CHESS_COM_PACKAGE = "com.chess"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()

        // Если ключ уже сохранён — сразу показываем кнопку старта
        if (keyManager.isKeyValid()) {
            showUnlocked()
        }
    }

    private fun setupUI() {
        // Кнопка "Начать игру"
        binding.btnStartGame.setOnClickListener {
            val enteredKey = binding.etAccessKey.text.toString().trim()

            if (keyManager.isKeyValid() || keyManager.validateAndSave(enteredKey)) {
                checkOverlayPermissionAndLaunch()
            } else {
                binding.etAccessKey.error = "Неверный ключ"
                shake(binding.etAccessKey)
            }
        }
    }

    private fun showUnlocked() {
        binding.etAccessKey.setText("••••••••••••••••••••")
        binding.etAccessKey.isEnabled = false
        binding.btnStartGame.text = getString(R.string.launch_chess)
    }

    private fun checkOverlayPermissionAndLaunch() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            // Запрашиваем разрешение на overlay
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST)
        } else {
            launchChessCom()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (Settings.canDrawOverlays(this)) {
                launchChessCom()
            } else {
                Toast.makeText(this, "Разрешение на overlay необходимо", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun launchChessCom() {
        // Запускаем OverlayService
        val serviceIntent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        // Пытаемся открыть Chess.com
        val pm = packageManager
        val launchIntent = pm.getLaunchIntentForPackage(CHESS_COM_PACKAGE)

        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            // Chess.com не установлен — открываем Play Store
            Toast.makeText(this, "Устанавливаем Chess.com…", Toast.LENGTH_SHORT).show()
            val storeIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("market://details?id=$CHESS_COM_PACKAGE")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(storeIntent)
        }

        // Сворачиваем наше приложение
        moveTaskToBack(true)
    }

    private fun shake(view: android.view.View) {
        val anim = android.view.animation.AnimationUtils.loadAnimation(this, R.anim.shake)
        view.startAnimation(anim)
    }
}
