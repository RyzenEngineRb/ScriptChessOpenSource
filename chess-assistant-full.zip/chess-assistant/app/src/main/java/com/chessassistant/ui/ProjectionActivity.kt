package com.chessassistant.ui

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import com.chessassistant.overlay.OverlayService
import com.chessassistant.vision.ScreenCaptureHelper

/**
 * Thin activity only to request MediaProjection permission.
 */
class ProjectionActivity : Activity() {

    companion object {
        const val REQ = 9001
        const val ACTION_PROJECTION_READY = "com.chessassistant.PROJECTION_READY"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ) {
            if (resultCode == RESULT_OK && data != null) {
                ScreenCaptureHelper(applicationContext).attachFromResult(resultCode, data)
                sendBroadcast(Intent(ACTION_PROJECTION_READY).setPackage(packageName))
                // Ask overlay to scan
                try {
                    val i = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SCAN_BOARD)
                    startService(i)
                } catch (_: Exception) {}
            }
        }
        finish()
    }
}
