package com.chessassistant.overlay

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.chessassistant.ChessApp
import com.chessassistant.R
import com.chessassistant.databinding.OverlayBubbleBinding
import com.chessassistant.databinding.OverlayPanelBinding
import com.chessassistant.engine.ChessEngine
import com.chessassistant.engine.StockfishApiHelper
import com.chessassistant.ui.MainActivity
import kotlinx.coroutines.*

class OverlayService : Service() {

    companion object {
        var isRunning = false
            private set
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private lateinit var bubbleBinding: OverlayBubbleBinding
    private lateinit var panelBinding: OverlayPanelBinding

    private val engine = ChessEngine()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var bubbleX = 0
    private var bubbleY = 200
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var initialX = 0
    private var initialY = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(1, buildNotification())
        showBubble()
    }

    // ── Плавающий пузырь (всегда поверх) ──────────────────────────────────
    private fun showBubble() {
        val inflater = LayoutInflater.from(this)
        bubbleBinding = OverlayBubbleBinding.inflate(inflater)
        bubbleView = bubbleBinding.root

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleX
            y = bubbleY
        }

        // Drag + click
        bubbleView!!.setOnTouchListener(object : View.OnTouchListener {
            var isDragging = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDragging = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) isDragging = true
                        params.x = initialX + dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(bubbleView, params)
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!isDragging) togglePanel()
                    }
                }
                return true
            }
        })

        windowManager.addView(bubbleView, params)
    }

    // ── Панель ассистента ──────────────────────────────────────────────────
    private fun togglePanel() {
        if (panelView != null) {
            dismissPanel()
        } else {
            showPanel()
        }
    }

    private fun showPanel() {
        val inflater = LayoutInflater.from(this)
        panelBinding = OverlayPanelBinding.inflate(inflater)
        panelView = panelBinding.root

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 80
        }

        panelBinding.btnClose.setOnClickListener { dismissPanel() }
        panelBinding.btnAnalyze.setOnClickListener { analyzePosition() }
        panelBinding.btnNewGame.setOnClickListener { engine.reset(); updateBoardDisplay() }

        // Касание вне панели — закрыть
        panelView!!.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_OUTSIDE) dismissPanel()
            false
        }

        windowManager.addView(panelView, params)
        updateBoardDisplay()
    }

    private fun dismissPanel() {
        panelView?.let {
            windowManager.removeView(it)
            panelView = null
        }
    }

    // ── Анализ позиции ─────────────────────────────────────────────────────
    private fun analyzePosition() {
        panelBinding.tvSuggestion.text = "Analyzing…"
        panelBinding.tvScore.text = ""
        panelBinding.btnAnalyze.isEnabled = false

        scope.launch {
            // Сначала пробуем lichess Cloud Eval (Stockfish глубина 20+)
            val apiResult = StockfishApiHelper.analyze(engine.getFen())

            if (apiResult.isSuccess) {
                val r = apiResult.getOrThrow()
                panelBinding.tvSuggestion.text = r.bestMove
                panelBinding.tvScore.text = "${StockfishApiHelper.formatScore(r)}  depth ${r.depth}"
            } else {
                // Fallback: локальный минимакс
                val localMove = withContext(Dispatchers.Default) { engine.getBestMove() }
                panelBinding.tvSuggestion.text = localMove
                panelBinding.tvScore.text = "local engine"
            }

            panelBinding.btnAnalyze.isEnabled = true
        }
    }

    private fun updateBoardDisplay() {
        panelBinding.tvFen.text = engine.getFen()
        val history = engine.getMoveHistory()
        panelBinding.tvMoves.text = if (history.isEmpty()) "No moves yet"
        else history.mapIndexed { i, m ->
            if (i % 2 == 0) "${i / 2 + 1}. $m" else m
        }.joinToString("  ")
    }

    // ── Foreground notification ────────────────────────────────────────────
    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, ChessApp.OVERLAY_CHANNEL_ID)
            .setContentTitle("Chess Assistant")
            .setContentText("Overlay active — tap bubble for hints")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        scope.cancel()
        bubbleView?.let { windowManager.removeView(it) }
        panelView?.let { windowManager.removeView(it) }
        super.onDestroy()
    }
}
