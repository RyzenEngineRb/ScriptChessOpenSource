package com.chessassistant.overlay

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.chessassistant.ChessApp
import com.chessassistant.R
import com.chessassistant.databinding.OverlayBubbleBinding
import com.chessassistant.databinding.OverlayPanelBinding
import com.chessassistant.engine.ChessEngine
import com.chessassistant.engine.StockfishApiHelper
import com.chessassistant.ui.MainActivity
import kotlinx.coroutines.*

class OverlayService : Service() {

    companion object {
        private const val TAG = "ChessOverlay"
        var isRunning = false
            private set
    }

    private var windowManager: WindowManager? = null
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleBinding: OverlayBubbleBinding? = null
    private var panelBinding: OverlayPanelBinding? = null
    private var themedContext: Context? = null

    private var arrowView: ArrowOverlayView? = null
    private lateinit var boardGeometry: BoardGeometry
    private var arrowsEnabled = true


    private val engine = ChessEngine()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubbleX = 40
    private var bubbleY = 300
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var initialX = 0
    private var initialY = 0
    private var bubbleParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            isRunning = true
            startForeground(1, buildNotification())
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            boardGeometry = BoardGeometry(this)
            // Theme needed so layout inflation from Service does not crash
            themedContext = ContextThemeWrapper(this, R.style.Theme_ChessAssistant)
            mainHandler.postDelayed({ safeShowBubble() }, 300)
        } catch (e: Exception) {
            Log.e(TAG, "onCreate failed", e)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun safeShowBubble() {
        try {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Нет разрешения «Поверх других окон»", Toast.LENGTH_LONG).show()
                stopSelf()
                return
            }
            if (bubbleView != null) return
            showBubble()
        } catch (e: Exception) {
            Log.e(TAG, "safeShowBubble failed", e)
            Toast.makeText(this, "Ошибка overlay: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun showBubble() {
        val ctx = themedContext ?: this
        val inflater = LayoutInflater.from(ctx)
        bubbleBinding = OverlayBubbleBinding.inflate(inflater)
        bubbleView = bubbleBinding!!.root

        val params = buildOverlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleX
            y = bubbleY
        }
        bubbleParams = params

        bubbleView!!.setOnTouchListener(object : View.OnTouchListener {
            var isDragging = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                try {
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            initialX = params.x
                            initialY = params.y
                            initialTouchX = event.rawX
                            initialTouchY = event.rawY
                            isDragging = false
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (event.rawX - initialTouchX).toInt()
                            val dy = (event.rawY - initialTouchY).toInt()
                            if (kotlin.math.abs(dx) > 15 || kotlin.math.abs(dy) > 15) {
                                isDragging = true
                            }
                            if (isDragging) {
                                params.x = initialX + dx
                                params.y = initialY + dy
                                try {
                                    windowManager?.updateViewLayout(bubbleView, params)
                                } catch (_: Exception) { }
                            }
                            return true
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            if (!isDragging) {
                                bubbleX = params.x
                                bubbleY = params.y
                                vibrateClick()
                                mainHandler.post { togglePanel() }
                            } else {
                                bubbleX = params.x
                                bubbleY = params.y
                            }
                            return true
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "bubble touch error", e)
                }
                return true
            }
        })

        windowManager?.addView(bubbleView, params)
        Log.i(TAG, "Bubble added at $bubbleX,$bubbleY")
    }

    private fun togglePanel() {
        try {
            if (panelView != null) {
                dismissPanel()
            } else {
                showPanel()
            }
        } catch (e: Exception) {
            Log.e(TAG, "togglePanel failed", e)
            Toast.makeText(this, "Панель: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPanel() {
        val ctx = themedContext ?: this
        val inflater = LayoutInflater.from(ctx)
        panelBinding = OverlayPanelBinding.inflate(inflater)
        panelView = panelBinding!!.root

        val width = (resources.displayMetrics.widthPixels * 0.90f).toInt()
        val params = buildOverlayParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            // Panel must receive touches; NOT_FOCUSABLE keeps soft-keyboard away
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 120
        }

        panelBinding!!.btnClose.setOnClickListener { dismissPanel() }
        panelBinding!!.btnAnalyze.setOnClickListener { analyzePosition() }
        panelBinding!!.btnNewGame.setOnClickListener {
            engine.reset()
            updateBoardDisplay()
        }
        panelBinding!!.btnClearHistory.setOnClickListener {
            engine.clearHistory()
            updateBoardDisplay()
            Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
        }
        panelBinding!!.btnSaveHistory.setOnClickListener {
            saveHistoryToPrefs()
            Toast.makeText(this, "History saved", Toast.LENGTH_SHORT).show()
        }
        panelBinding!!.btnDisable.setOnClickListener {
            disableAssist()
        }
        panelBinding!!.btnFlipBoard.setOnClickListener {
            boardGeometry.whiteAtBottom = !boardGeometry.whiteAtBottom
            Toast.makeText(
                this,
                if (boardGeometry.whiteAtBottom) "White at bottom" else "Black at bottom",
                Toast.LENGTH_SHORT
            ).show()
            // redraw last suggestion if any
            val last = engine.getMoveHistory().lastOrNull()
            if (last != null) showMoveArrow(last)
        }
        panelBinding!!.btnToggleArrows.setOnClickListener {
            arrowsEnabled = !arrowsEnabled
            panelBinding?.btnToggleArrows?.text = if (arrowsEnabled) "Arrows: ON" else "Arrows: OFF"
            if (!arrowsEnabled) clearMoveArrows()
            else {
                val last = engine.getMoveHistory().lastOrNull()
                if (last != null) showMoveArrow(last)
            }
        }

        try {
            windowManager?.addView(panelView, params)
            updateBoardDisplay()
            Log.i(TAG, "Panel added")
        } catch (e: Exception) {
            Log.e(TAG, "addView panel failed", e)
            Toast.makeText(this, "Не удалось открыть панель: ${e.message}", Toast.LENGTH_LONG).show()
            panelView = null
            panelBinding = null
        }
    }

    private fun dismissPanel() {
        try {
            panelView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) { }
        panelView = null
        panelBinding = null
    }

    private fun analyzePosition() {
        val binding = panelBinding ?: return
        binding.tvSuggestion.text = "Analyzing…"
        binding.tvScore.text = ""
        binding.btnAnalyze.isEnabled = false

        scope.launch {
            try {
                val apiResult = StockfishApiHelper.analyze(engine.getFen())
                if (apiResult.isSuccess) {
                    val r = apiResult.getOrThrow()
                    val moveText = r.bestMove
                    binding.tvSuggestion.text = moveText
                    binding.tvScore.text = "${StockfishApiHelper.formatScore(r)}  depth ${r.depth}"
                    if (moveText.isNotBlank() && moveText != "none") {
                        engine.appendHistory(moveText)
                        updateBoardDisplay()
                        showMoveArrow(moveText)
                    }
                } else {
                    val localMove = withContext(Dispatchers.Default) { engine.getBestMove() }
                    binding.tvSuggestion.text = localMove
                    binding.tvScore.text = "local engine"
                    if (localMove.isNotBlank()) {
                        engine.appendHistory(localMove)
                        updateBoardDisplay()
                        showMoveArrow(localMove)
                    }
                }
            } catch (e: Exception) {
                binding.tvSuggestion.text = "Error"
                binding.tvScore.text = e.message ?: ""
            } finally {
                binding.btnAnalyze.isEnabled = true
            }
        }
    }

    private fun updateBoardDisplay() {
        val binding = panelBinding ?: return
        try {
            binding.tvFen.text = engine.getFen()
            val history = engine.getMoveHistory()
            binding.tvMoves.text = if (history.isEmpty()) "No moves yet"
            else history.mapIndexed { i, m ->
                if (i % 2 == 0) "${i / 2 + 1}. $m" else m
            }.joinToString("  ")
        } catch (_: Exception) { }
    }

    private fun buildOverlayParams(width: Int, height: Int, flags: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        return WindowManager.LayoutParams(width, height, type, flags, PixelFormat.TRANSLUCENT).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrateClick() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(VibratorManager::class.java)
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    v?.vibrate(30)
                }
            }
        } catch (_: Exception) { }
    }


    private fun saveHistoryToPrefs() {
        try {
            val prefs = getSharedPreferences("chess_history", MODE_PRIVATE)
            val joined = engine.getMoveHistory().joinToString("\n")
            prefs.edit().putString("moves", joined).apply()
        } catch (_: Exception) { }
    }

    private fun loadHistoryFromPrefs() {
        try {
            val prefs = getSharedPreferences("chess_history", MODE_PRIVATE)
            val joined = prefs.getString("moves", null) ?: return
            if (joined.isBlank()) return
            engine.setHistory(joined.split("\n").filter { it.isNotBlank() })
        } catch (_: Exception) { }
    }

    private fun disableAssist() {
        try {
            dismissPanel()
            clearMoveArrows()
            try { arrowView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
            arrowView = null
            try { bubbleView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
            bubbleView = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            // Полностью завершить процесс приложения
            android.os.Process.killProcess(android.os.Process.myPid())
        } catch (e: Exception) {
            Log.e(TAG, "disableAssist failed", e)
            stopSelf()
        }
    }


    private fun ensureArrowLayer() {
        if (arrowView != null) return
        try {
            val view = ArrowOverlayView(this)
            arrowView = view
            val params = buildOverlayParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 0
                y = 0
            }
            windowManager?.addView(view, params)
            Log.i(TAG, "Arrow layer added")
        } catch (e: Exception) {
            Log.e(TAG, "arrow layer failed", e)
            arrowView = null
        }
    }

    private fun showMoveArrow(moveText: String) {
        if (!arrowsEnabled) return
        try {
            ensureArrowLayer()
            val parsed = boardGeometry.parseMove(moveText) ?: run {
                Log.w(TAG, "Cannot parse move: $moveText")
                return
            }
            val from = boardGeometry.squareCenter(parsed.first)
            val to = boardGeometry.squareCenter(parsed.second)
            if (from == null || to == null) return
            arrowView?.setArrows(listOf(ArrowOverlayView.Arrow(from, to)))
        } catch (e: Exception) {
            Log.e(TAG, "showMoveArrow failed", e)
        }
    }

    private fun clearMoveArrows() {
        try {
            arrowView?.clearArrows()
        } catch (_: Exception) { }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, ChessApp.OVERLAY_CHANNEL_ID)
            .setContentTitle("Chess Assistant")
            .setContentText("Overlay active — tap bubble for panel")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        scope.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        try { bubbleView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        try { panelView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        try { arrowView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        bubbleView = null
        panelView = null
        arrowView = null
        super.onDestroy()
    }
}
