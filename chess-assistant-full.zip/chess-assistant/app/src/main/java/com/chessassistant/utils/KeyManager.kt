package com.chessassistant.utils

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class KeyManager(context: Context) {

    companion object {
        private const val PREFS_FILE = "chess_secure_prefs"
        private const val KEY_PREF = "access_key"
        private const val VALID_KEY = "Unfly---Reborn---Fest8294810Mjk"
    }

    private val prefs = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            PREFS_FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback на обычные prefs если криптография недоступна
        context.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
    }

    fun validateAndSave(key: String): Boolean {
        return if (key == VALID_KEY) {
            prefs.edit().putString(KEY_PREF, key).apply()
            true
        } else false
    }

    fun isKeyValid(): Boolean {
        val saved = prefs.getString(KEY_PREF, null)
        return saved == VALID_KEY
    }

    fun clearKey() {
        prefs.edit().remove(KEY_PREF).apply()
    }
}
