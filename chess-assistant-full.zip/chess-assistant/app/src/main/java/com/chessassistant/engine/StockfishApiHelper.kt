package com.chessassistant.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Анализ позиции через lichess.org Cloud Evaluation API.
 * Бесплатно, без API-ключа, до глубины 20.
 *
 * Docs: https://lichess.org/api#tag/Analysis
 */
object StockfishApiHelper {

    private const val BASE_URL = "https://lichess.org/api/cloud-eval"
    private const val TIMEOUT_MS = 8000

    data class AnalysisResult(
        val bestMove: String,       // e.g. "e2e4"
        val score: Int,             // centipawns
        val depth: Int,
        val mate: Int?,             // ходов до мата, null если не мат
        val pv: String              // главный вариант
    )

    /**
     * Возвращает лучший ход для позиции [fen].
     * Вызывать в IO-корутине.
     */
    suspend fun analyze(fen: String, multiPv: Int = 1): Result<AnalysisResult> =
        withContext(Dispatchers.IO) {
            runCatching {
                val encoded = URLEncoder.encode(fen, "UTF-8")
                val url = URL("$BASE_URL?fen=$encoded&multiPv=$multiPv")

                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = TIMEOUT_MS
                    readTimeout = TIMEOUT_MS
                    setRequestProperty("Accept", "application/json")
                }

                val code = conn.responseCode
                if (code != 200) error("lichess API returned HTTP $code")

                val body = conn.inputStream.bufferedReader().readText()
                conn.disconnect()

                parseLichessResponse(body)
            }
        }

    private fun parseLichessResponse(json: String): AnalysisResult {
        val root = JSONObject(json)
        val pvs = root.getJSONArray("pvs")
        val best = pvs.getJSONObject(0)

        val moves = best.getString("moves")
        val bestMove = moves.split(" ").first()          // "e2e4"
        val prettyMove = uciToArrow(bestMove)            // "e2 → e4"

        val cp = if (best.has("cp")) best.getInt("cp") else null
        val mate = if (best.has("mate")) best.getInt("mate") else null
        val depth = root.optInt("depth", 0)

        return AnalysisResult(
            bestMove = prettyMove,
            score = cp ?: 0,
            depth = depth,
            mate = mate,
            pv = moves
        )
    }

    /** "e2e4" → "e2 → e4" */
    private fun uciToArrow(uci: String): String {
        if (uci.length < 4) return uci
        return "${uci.substring(0, 2)} → ${uci.substring(2, 4)}"
    }

    /** Форматирует оценку для UI: "+0.5", "-1.2", "M3" */
    fun formatScore(result: AnalysisResult): String {
        result.mate?.let { return "Mate in $it" }
        val pawns = result.score / 100.0
        return if (pawns >= 0) "+%.1f".format(pawns) else "%.1f".format(pawns)
    }
}
