package com.chessassistant.engine

/**
 * Лёгкий шахматный движок на Kotlin.
 * Хранит FEN, историю ходов, считает лучший ход минимакс (глубина 3).
 * Для продакшена замените на Stockfish через NDK или lichess.org API.
 */
class ChessEngine {

    // FEN начальной позиции
    private var fen: String = START_FEN
    private val moveHistory = mutableListOf<String>()
    private var board = Array(8) { Array(8) { ' ' } }
    private var whiteToMove = true

    companion object {
        const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        // Веса фигур
        val PIECE_VALUE = mapOf(
            'P' to 100, 'N' to 320, 'B' to 330, 'R' to 500, 'Q' to 900, 'K' to 20000,
            'p' to -100, 'n' to -320, 'b' to -330, 'r' to -500, 'q' to -900, 'k' to -20000
        )
    }

    init {
        parseFen(START_FEN)
    }

    fun reset() {
        fen = START_FEN
        moveHistory.clear()
        parseFen(START_FEN)
        whiteToMove = true
    }

    fun getFen(): String = fen

    fun setFen(newFen: String) {
        fen = newFen.trim()
        parseFen(fen)
        val parts = fen.split(" ")
        whiteToMove = parts.getOrElse(1) { "w" } == "w"
    }

    fun setSideToMove(white: Boolean) {
        whiteToMove = white
        val parts = fen.split(" ").toMutableList()
        while (parts.size < 2) parts.add("w")
        parts[1] = if (white) "w" else "b"
        fen = parts.joinToString(" ")
    }

    fun isWhiteToMove(): Boolean = whiteToMove


    fun setSideToMove(white: Boolean) {
        whiteToMove = white
        // rebuild fen side flag
        val parts = fen.split(" ").toMutableList()
        if (parts.size >= 2) {
            parts[1] = if (white) "w" else "b"
            fen = parts.joinToString(" ")
        } else {
            fen = boardToFen()
        }
    }

    fun isWhiteToMove(): Boolean = whiteToMove

    /** Load a full FEN string into the engine state. */
    fun loadFen(fenStr: String) {
        try {
            parseFen(fenStr)
            fen = fenStr.trim()
            val parts = fenStr.trim().split(" ")
            whiteToMove = parts.getOrElse(1) { "w" } == "w"
        } catch (_: Exception) {
            // keep previous
        }
    }

    fun getMoveHistory(): List<String> = moveHistory.toList()

    /** Добавить ход в историю (без изменения доски) — для лога подсказок */
    fun appendHistory(move: String) {
        if (move.isNotBlank()) moveHistory.add(move.trim())
    }

    fun clearHistory() {
        moveHistory.clear()
    }

    fun setHistory(moves: List<String>) {
        moveHistory.clear()
        moveHistory.addAll(moves)
    }


    // ── Парсинг FEN ────────────────────────────────────────────────────────
    private fun parseFen(fenStr: String) {
        val parts = fenStr.split(" ")
        val rows = parts[0].split("/")
        board = Array(8) { Array(8) { ' ' } }
        rows.forEachIndexed { rank, row ->
            var file = 0
            row.forEach { ch ->
                if (ch.isDigit()) {
                    file += ch.digitToInt()
                } else {
                    board[rank][file] = ch
                    file++
                }
            }
        }
        whiteToMove = parts.getOrElse(1) { "w" } == "w"
    }

    // ── Генерация FEN из доски ─────────────────────────────────────────────
    private fun boardToFen(): String {
        val sb = StringBuilder()
        for (rank in 0..7) {
            var empty = 0
            for (file in 0..7) {
                val p = board[rank][file]
                if (p == ' ') {
                    empty++
                } else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(p)
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank < 7) sb.append('/')
        }
        sb.append(if (whiteToMove) " w" else " b")
        sb.append(" KQkq - 0 1")
        return sb.toString()
    }

    // ── Лучший ход ─────────────────────────────────────────────────────────
    fun getBestMove(): String {
        val moves = generateAllMoves(whiteToMove)
        if (moves.isEmpty()) return "Нет доступных ходов"

        var bestMove: Move? = null
        var bestScore = if (whiteToMove) Int.MIN_VALUE else Int.MAX_VALUE

        moves.forEach { move ->
            val saved = applyMove(move)
            val score = minimax(2, !whiteToMove, Int.MIN_VALUE, Int.MAX_VALUE)
            undoMove(move, saved)

            if (whiteToMove && score > bestScore) {
                bestScore = score; bestMove = move
            } else if (!whiteToMove && score < bestScore) {
                bestScore = score; bestMove = move
            }
        }

        return bestMove?.toAlgebraic() ?: moves.first().toAlgebraic()
    }

    private fun minimax(depth: Int, maximizing: Boolean, alpha: Int, beta: Int): Int {
        if (depth == 0) return evaluate()

        val moves = generateAllMoves(maximizing)
        if (moves.isEmpty()) return if (maximizing) -9999 else 9999

        var a = alpha; var b = beta
        var best = if (maximizing) Int.MIN_VALUE else Int.MAX_VALUE

        for (move in moves) {
            val saved = applyMove(move)
            val score = minimax(depth - 1, !maximizing, a, b)
            undoMove(move, saved)

            if (maximizing) {
                best = maxOf(best, score); a = maxOf(a, score)
            } else {
                best = minOf(best, score); b = minOf(b, score)
            }
            if (b <= a) break
        }
        return best
    }

    // ── Оценка позиции ─────────────────────────────────────────────────────
    private fun evaluate(): Int {
        var score = 0
        for (rank in 0..7) for (file in 0..7) {
            score += PIECE_VALUE[board[rank][file]] ?: 0
        }
        return score
    }

    // ── Генерация ходов (упрощённая) ───────────────────────────────────────
    private fun generateAllMoves(white: Boolean): List<Move> {
        val moves = mutableListOf<Move>()
        for (rank in 0..7) for (file in 0..7) {
            val piece = board[rank][file]
            if (piece == ' ') continue
            if (white && piece.isLowerCase()) continue
            if (!white && piece.isUpperCase()) continue
            moves.addAll(generatePieceMoves(rank, file, piece))
        }
        return moves
    }

    private fun generatePieceMoves(rank: Int, file: Int, piece: Char): List<Move> {
        return when (piece.lowercaseChar()) {
            'p' -> pawnMoves(rank, file, piece.isUpperCase())
            'n' -> knightMoves(rank, file, piece.isUpperCase())
            'b' -> slidingMoves(rank, file, piece.isUpperCase(), listOf(1 to 1, 1 to -1, -1 to 1, -1 to -1))
            'r' -> slidingMoves(rank, file, piece.isUpperCase(), listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1))
            'q' -> slidingMoves(rank, file, piece.isUpperCase(), listOf(1 to 1, 1 to -1, -1 to 1, -1 to -1, 1 to 0, -1 to 0, 0 to 1, 0 to -1))
            'k' -> kingMoves(rank, file, piece.isUpperCase())
            else -> emptyList()
        }
    }

    private fun inBounds(r: Int, f: Int) = r in 0..7 && f in 0..7

    private fun isEnemy(piece: Char, white: Boolean) =
        if (white) piece.isLowerCase() && piece != ' ' else piece.isUpperCase()

    private fun isEmpty(r: Int, f: Int) = board[r][f] == ' '

    private fun pawnMoves(rank: Int, file: Int, white: Boolean): List<Move> {
        val moves = mutableListOf<Move>()
        val dir = if (white) -1 else 1
        val startRank = if (white) 6 else 1

        // Вперёд
        if (inBounds(rank + dir, file) && isEmpty(rank + dir, file)) {
            moves.add(Move(rank, file, rank + dir, file))
            if (rank == startRank && isEmpty(rank + 2 * dir, file))
                moves.add(Move(rank, file, rank + 2 * dir, file))
        }
        // Взятия
        for (df in listOf(-1, 1)) {
            val nr = rank + dir; val nf = file + df
            if (inBounds(nr, nf) && isEnemy(board[nr][nf], white))
                moves.add(Move(rank, file, nr, nf))
        }
        return moves
    }

    private fun knightMoves(rank: Int, file: Int, white: Boolean): List<Move> {
        val deltas = listOf(-2 to -1, -2 to 1, -1 to -2, -1 to 2, 1 to -2, 1 to 2, 2 to -1, 2 to 1)
        return deltas.mapNotNull { (dr, df) ->
            val nr = rank + dr; val nf = file + df
            if (inBounds(nr, nf) && (isEmpty(nr, nf) || isEnemy(board[nr][nf], white)))
                Move(rank, file, nr, nf) else null
        }
    }

    private fun slidingMoves(rank: Int, file: Int, white: Boolean, dirs: List<Pair<Int, Int>>): List<Move> {
        val moves = mutableListOf<Move>()
        for ((dr, df) in dirs) {
            var nr = rank + dr; var nf = file + df
            while (inBounds(nr, nf)) {
                val target = board[nr][nf]
                if (target == ' ') { moves.add(Move(rank, file, nr, nf)); nr += dr; nf += df }
                else { if (isEnemy(target, white)) moves.add(Move(rank, file, nr, nf)); break }
            }
        }
        return moves
    }

    private fun kingMoves(rank: Int, file: Int, white: Boolean): List<Move> {
        val deltas = listOf(-1 to -1, -1 to 0, -1 to 1, 0 to -1, 0 to 1, 1 to -1, 1 to 0, 1 to 1)
        return deltas.mapNotNull { (dr, df) ->
            val nr = rank + dr; val nf = file + df
            if (inBounds(nr, nf) && (isEmpty(nr, nf) || isEnemy(board[nr][nf], white)))
                Move(rank, file, nr, nf) else null
        }
    }

    // ── Применение / откат хода ────────────────────────────────────────────
    data class Move(val fromR: Int, val fromF: Int, val toR: Int, val toF: Int) {
        fun toAlgebraic(): String {
            val files = "abcdefgh"
            val from = "${files[fromF]}${8 - fromR}"
            val to = "${files[toF]}${8 - toR}"
            return "$from → $to"
        }
    }

    private fun applyMove(move: Move): Char {
        val captured = board[move.toR][move.toF]
        board[move.toR][move.toF] = board[move.fromR][move.fromF]
        board[move.fromR][move.fromF] = ' '
        whiteToMove = !whiteToMove
        fen = boardToFen()
        return captured
    }

    private fun undoMove(move: Move, captured: Char) {
        board[move.fromR][move.fromF] = board[move.toR][move.toF]
        board[move.toR][move.toF] = captured
        whiteToMove = !whiteToMove
        fen = boardToFen()
    }
}
