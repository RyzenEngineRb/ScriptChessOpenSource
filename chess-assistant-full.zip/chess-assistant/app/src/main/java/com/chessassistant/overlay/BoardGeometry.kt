package com.chessassistant.overlay

import android.content.Context
import android.graphics.PointF
import android.graphics.RectF
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * Maps chess squares (a1..h8) to screen coordinates.
 * Default region approximates Chess.com mobile board (full width, centered).
 * Call [setBoardRect] after calibration if needed.
 */
class BoardGeometry(context: Context) {

    private val dm: DisplayMetrics = context.resources.displayMetrics
    private var boardRect: RectF
    /** true = a1 at bottom-left (white perspective), false = flipped */
    var whiteAtBottom: Boolean = true

    init {
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        // Typical Chess.com mobile: board ~ full width, square, slightly above center
        val size = w * 0.98f
        val left = (w - size) / 2f
        val top = h * 0.22f
        boardRect = RectF(left, top, left + size, top + size)
    }

    fun setBoardRect(rect: RectF) {
        boardRect = RectF(rect)
    }

    fun getBoardRect(): RectF = RectF(boardRect)

    fun squareCenter(square: String): PointF? {
        val sq = square.trim().lowercase()
        if (sq.length < 2) return null
        val file = sq[0] - 'a' // 0..7
        val rank = sq[1] - '1' // 0..7
        if (file !in 0..7 || rank !in 0..7) return null

        val col = if (whiteAtBottom) file else 7 - file
        val row = if (whiteAtBottom) 7 - rank else rank // rank 8 at top when white at bottom

        val cellW = boardRect.width() / 8f
        val cellH = boardRect.height() / 8f
        val x = boardRect.left + (col + 0.5f) * cellW
        val y = boardRect.top + (row + 0.5f) * cellH
        return PointF(x, y)
    }

    /**
     * Parse moves like "e2e4", "e2 → e4", "e2-e4", "Nf3" (piece moves need from/to separately).
     * Returns Pair(from, to) or null.
     */
    fun parseMove(text: String): Pair<String, String>? {
        val t = text.trim()
            .replace("→", "")
            .replace("->", "")
            .replace("—", "")
            .replace("–", "")
            .replace("-", "")
            .replace(" ", "")
            .lowercase()
        // e2e4
        val re = Regex("""([a-h][1-8])([a-h][1-8])""")
        val m = re.find(t) ?: return null
        return m.groupValues[1] to m.groupValues[2]
    }
}
