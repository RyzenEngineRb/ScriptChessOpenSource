package com.chessassistant.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.chessassistant.databinding.ActivityWebCoachBinding
import com.chessassistant.engine.ChessEngine
import com.chessassistant.engine.StockfishApiHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Chess.com / Lichess inside WebView + JS bridge for FEN.
 * Stable alternative to MediaProjection overlay.
 */
class WebCoachActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWebCoachBinding
    private val engine = ChessEngine()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastFen: String? = null
    private var bridgeInjected = false

    companion object {
        private const val TAG = "WebCoach"
        private const val URL_CHESSCOM = "https://www.chess.com/play"
        private const val URL_LICHESS = "https://lichess.org"
        private const val BRIDGE_ASSET = "js/board_bridge.js"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            binding = ActivityWebCoachBinding.inflate(layoutInflater)
            setContentView(binding.root)
            setupWebView()
            setupButtons()
            binding.webView.loadUrl(URL_CHESSCOM)
        } catch (e: Exception) {
            Log.e(TAG, "onCreate failed", e)
            Toast.makeText(this, "WebCoach error: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(binding.webView, true)

        binding.webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = WebSettings.getDefaultUserAgent(this@WebCoachActivity)
                .replace("; wv", "") // look less like embedded WebView for some sites
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
        }

        binding.webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        binding.webView.webChromeClient = WebChromeClient()
        binding.webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false // stay in WebView
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                bridgeInjected = false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                injectBridge()
            }
        }
    }

    private fun injectBridge() {
        if (bridgeInjected) return
        try {
            val js = assets.open(BRIDGE_ASSET).bufferedReader().use { it.readText() }
            binding.webView.evaluateJavascript(js, null)
            bridgeInjected = true
            Log.i(TAG, "bridge injected")
        } catch (e: Exception) {
            Log.e(TAG, "inject failed", e)
        }
    }

    private fun setupButtons() {
        binding.btnChessCom.setOnClickListener {
            bridgeInjected = false
            binding.webView.loadUrl(URL_CHESSCOM)
        }
        binding.btnLichess.setOnClickListener {
            bridgeInjected = false
            binding.webView.loadUrl(URL_LICHESS)
        }
        binding.btnRefreshFen.setOnClickListener {
            injectBridge()
            binding.webView.evaluateJavascript(
                "try{window.__caReadBoard&&window.__caReadBoard()}catch(e){}",
                null
            )
            Toast.makeText(this, "Reading board…", Toast.LENGTH_SHORT).show()
        }
        binding.btnAnalyze.setOnClickListener { analyze() }
    }

    private fun analyze() {
        val fen = lastFen
        if (fen.isNullOrBlank()) {
            Toast.makeText(this, "Нет FEN — откройте партию и нажмите Read FEN", Toast.LENGTH_LONG).show()
            binding.webView.evaluateJavascript(
                "try{window.__caReadBoard&&window.__caReadBoard()}catch(e){}",
                null
            )
            return
        }
        binding.tvSuggestion.text = "Analyzing…"
        binding.tvScore.text = ""
        binding.btnAnalyze.isEnabled = false

        lifecycleScope.launch {
            try {
                val api = StockfishApiHelper.analyze(fen)
                if (api.isSuccess) {
                    val r = api.getOrThrow()
                    binding.tvSuggestion.text = r.bestMove
                    binding.tvScore.text = "${StockfishApiHelper.formatScore(r)}  depth ${r.depth}"
                    engine.setFen(fen)
                    engine.appendHistory(r.bestMove)
                } else {
                    engine.setFen(fen)
                    val local = withContext(Dispatchers.Default) { engine.getBestMove() }
                    binding.tvSuggestion.text = local
                    binding.tvScore.text = "local engine"
                }
            } catch (e: Exception) {
                binding.tvSuggestion.text = "Error"
                binding.tvScore.text = e.message ?: ""
            } finally {
                binding.btnAnalyze.isEnabled = true
            }
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun onBoardUpdate(json: String) {
            mainHandler.post {
                try {
                    val o = JSONObject(json)
                    when (o.optString("type")) {
                        "ready" -> {
                            Log.i(TAG, "bridge ready ${o.optString("url")}")
                        }
                        "fen" -> {
                            val fen = o.optString("fen")
                            if (fen.isNotBlank() && fen != lastFen) {
                                lastFen = fen
                                binding.tvFen.text = "FEN: $fen"
                                val src = o.optString("source", "?")
                                if (binding.tvSuggestion.text.startsWith("Open") ||
                                    binding.tvSuggestion.text.startsWith("No FEN")
                                ) {
                                    binding.tvSuggestion.text = "Position live · $src"
                                }
                            }
                        }
                        "nofen" -> {
                            if (lastFen == null) {
                                binding.tvFen.text = "FEN: — (не на доске?)"
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "bridge parse", e)
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        try {
            binding.webView.apply {
                loadUrl("about:blank")
                stopLoading()
                destroy()
            }
        } catch (_: Exception) {}
        super.onDestroy()
    }
}
