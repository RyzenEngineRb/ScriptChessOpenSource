/**
 * Board bridge for Chess.com / Lichess inside WebView.
 * Posts messages to Android: AndroidBridge.onBoardUpdate(json)
 */
(function () {
  if (window.__caBoardBridgeInstalled) return;
  window.__caBoardBridgeInstalled = true;

  function post(obj) {
    try {
      if (window.AndroidBridge && window.AndroidBridge.onBoardUpdate) {
        window.AndroidBridge.onBoardUpdate(JSON.stringify(obj));
      }
    } catch (e) {}
  }

  function findChessComBoard() {
    var selectors = [
      "wc-chess-board",
      "chess-board",
      "#board-single",
      "#board",
      "[class*='board']"
    ];
    for (var i = 0; i < selectors.length; i++) {
      var el = document.querySelector(selectors[i]);
      if (el) return el;
    }
    return null;
  }

  function fenFromChessCom() {
    var board = findChessComBoard();
    if (!board) return null;

    // Prefer official game API when available
    try {
      if (board.game && typeof board.game.getFEN === "function") {
        var fen = board.game.getFEN();
        var playingAs = null;
        try {
          if (typeof board.game.getPlayingAs === "function") {
            playingAs = board.game.getPlayingAs(); // 1 white, 2 black often
          }
        } catch (e) {}
        return {
          fen: fen,
          source: "chesscom-api",
          playingAs: playingAs,
          flipped: !!(board.game.isFlipped && board.game.isFlipped())
        };
      }
    } catch (e) {}

    // Fallback: DOM piece classes (piece wp square-XX)
    try {
      var pieces = board.querySelectorAll(".piece, [class*='piece']");
      if (!pieces || !pieces.length) return null;
      var grid = {};
      pieces.forEach(function (p) {
        var cls = p.className || "";
        var sq = cls.match(/square-([0-9]{2})/);
        if (!sq) return;
        var file = parseInt(sq[1][0], 10) - 1; // 1-8
        var rank = parseInt(sq[1][1], 10) - 1;
        if (file < 0 || file > 7 || rank < 0 || rank > 7) return;
        var map = {
          wp: "P", wn: "N", wb: "B", wr: "R", wq: "Q", wk: "K",
          bp: "p", bn: "n", bb: "b", br: "r", bq: "q", bk: "k"
        };
        var key = null;
        Object.keys(map).forEach(function (k) {
          if (cls.indexOf(k) !== -1) key = map[k];
        });
        if (key) grid[file + "," + rank] = key;
      });
      var rows = [];
      for (var r = 7; r >= 0; r--) {
        var empty = 0, row = "";
        for (var f = 0; f < 8; f++) {
          var piece = grid[f + "," + r];
          if (!piece) empty++;
          else {
            if (empty) { row += empty; empty = 0; }
            row += piece;
          }
        }
        if (empty) row += empty;
        rows.push(row);
      }
      // side to move unknown from DOM alone
      var fen = rows.join("/") + " w - - 0 1";
      return { fen: fen, source: "chesscom-dom", playingAs: null, flipped: false };
    } catch (e) {
      return null;
    }
  }

  function fenFromLichess() {
    try {
      // Lichess often exposes chessground data
      var cg = document.querySelector("cg-container, .cg-wrap, chess-ground");
      if (!cg) return null;
      // Try global lichess object
      if (window.lichess && window.lichess.analysis && window.lichess.analysis.data) {
        var d = window.lichess.analysis.data;
        if (d.game && d.game.fen) {
          return { fen: d.game.fen, source: "lichess-analysis", playingAs: null, flipped: false };
        }
      }
      // DOM pieces: piece with style transform / data-key
      var pieces = document.querySelectorAll("piece");
      if (!pieces.length) return null;
      var grid = {};
      pieces.forEach(function (p) {
        var key = p.getAttribute("data-key") || p.getAttribute("cgKey");
        // square like a1
        var sq = key;
        if (!sq) {
          var m = (p.className || "").match(/square-([a-h][1-8])/);
          if (m) sq = m[1];
        }
        if (!sq || sq.length < 2) return;
        var file = sq.charCodeAt(0) - 97;
        var rank = parseInt(sq[1], 10) - 1;
        var color = (p.className || "").indexOf("white") >= 0 || (p.className || "").indexOf("w") === 0 ? "w" : "b";
        var role = "p";
        ["king","queen","rook","bishop","knight","pawn","k","q","r","b","n","p"].forEach(function (r) {
          if ((p.className || "").indexOf(r) >= 0) {
            if (r === "king" || r === "k") role = "k";
            else if (r === "queen" || r === "q") role = "q";
            else if (r === "rook" || r === "r") role = "r";
            else if (r === "bishop" || r === "b") role = "b";
            else if (r === "knight" || r === "n") role = "n";
            else role = "p";
          }
        });
        var ch = role;
        if (color === "w") ch = ch.toUpperCase();
        grid[file + "," + rank] = ch;
      });
      var rows = [];
      for (var r = 7; r >= 0; r--) {
        var empty = 0, row = "";
        for (var f = 0; f < 8; f++) {
          var piece = grid[f + "," + r];
          if (!piece) empty++;
          else {
            if (empty) { row += empty; empty = 0; }
            row += piece;
          }
        }
        if (empty) row += empty;
        rows.push(row);
      }
      return { fen: rows.join("/") + " w - - 0 1", source: "lichess-dom", playingAs: null, flipped: false };
    } catch (e) {
      return null;
    }
  }

  function readBoard() {
    var host = location.hostname || "";
    var data = null;
    if (host.indexOf("chess.com") !== -1) data = fenFromChessCom();
    else if (host.indexOf("lichess") !== -1) data = fenFromLichess();
    else data = fenFromChessCom() || fenFromLichess();
    if (data && data.fen) {
      post({ type: "fen", fen: data.fen, source: data.source, playingAs: data.playingAs, flipped: data.flipped, url: location.href });
    } else {
      post({ type: "nofen", url: location.href });
    }
    return data;
  }

  window.__caReadBoard = readBoard;

  // Poll every 1.2s while on a game page
  setInterval(function () {
    try { readBoard(); } catch (e) {}
  }, 1200);

  // Also on click / mutation
  document.addEventListener("click", function () {
    setTimeout(readBoard, 300);
  }, true);

  post({ type: "ready", url: location.href });
})();
