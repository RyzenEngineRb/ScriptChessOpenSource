#!/usr/bin/env bash
# ============================================================
# Chess Assistant — Bootstrap Script
# Запусти один раз после распаковки ZIP:
#   chmod +x bootstrap.sh && ./bootstrap.sh
# ============================================================
set -e

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║      Chess Assistant — Bootstrap         ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# 1. Проверка Java
if ! command -v java &>/dev/null; then
  echo "❌  Java не найдена. Установи JDK 17:"
  echo "    https://adoptium.net/temurin/releases/?version=17"
  exit 1
fi
JAVA_VER=$(java -version 2>&1 | head -1)
echo "✓  Java: $JAVA_VER"

# 2. Скачать gradle-wrapper.jar если отсутствует
WRAPPER_JAR="gradle/wrapper/gradle-wrapper.jar"
WRAPPER_URL="https://github.com/gradle/gradle/raw/v8.4.0/gradle/wrapper/gradle-wrapper.jar"

if [ ! -f "$WRAPPER_JAR" ]; then
  echo ""
  echo "⬇  Скачиваю gradle-wrapper.jar..."
  mkdir -p gradle/wrapper
  if command -v curl &>/dev/null; then
    curl -fsSL "$WRAPPER_URL" -o "$WRAPPER_JAR"
  elif command -v wget &>/dev/null; then
    wget -q "$WRAPPER_URL" -O "$WRAPPER_JAR"
  else
    echo "❌  Нужен curl или wget"
    exit 1
  fi
  echo "✓  gradle-wrapper.jar скачан"
else
  echo "✓  gradle-wrapper.jar уже есть"
fi

# 3. Права на gradlew
chmod +x gradlew
echo "✓  gradlew — исполняемый"

# 4. Проверка Android SDK
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  echo ""
  echo "⚠️   ANDROID_HOME не установлен."
  echo "    Установи Android Studio или Command Line Tools:"
  echo "    https://developer.android.com/studio"
  echo ""
  echo "    Затем добавь в ~/.bashrc или ~/.zshrc:"
  echo "    export ANDROID_HOME=\$HOME/Android/Sdk"
  echo "    export PATH=\$PATH:\$ANDROID_HOME/platform-tools"
  echo ""
  echo "    После этого запусти bootstrap.sh снова."
  exit 1
fi
echo "✓  ANDROID_HOME: ${ANDROID_HOME:-$ANDROID_SDK_ROOT}"

# 5. Сборка Debug APK
echo ""
echo "🔨  Собираю Debug APK..."
./gradlew assembleDebug --no-daemon

APK_PATH=$(find app/build/outputs/apk/debug -name "*.apk" 2>/dev/null | head -1)

if [ -n "$APK_PATH" ]; then
  SIZE=$(du -sh "$APK_PATH" | cut -f1)
  echo ""
  echo "╔══════════════════════════════════════════╗"
  echo "║  ✅  APK готов!                           ║"
  echo "║  📦  $APK_PATH"
  echo "║  📏  Размер: $SIZE                        ║"
  echo "╚══════════════════════════════════════════╝"
  echo ""
  echo "Установить на устройство:"
  echo "  adb install -r \"$APK_PATH\""
else
  echo "❌  APK не найден — проверь ошибки выше"
  exit 1
fi
