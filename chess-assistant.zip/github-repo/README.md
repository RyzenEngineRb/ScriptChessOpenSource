# Chess Assistant

Залей этот репозиторий на GitHub — Actions сам распакует ZIP и соберёт APK.

**Скачать APK:** Actions → последний запуск → Artifacts → `chess-assistant-debug`
