package com.chessassistant.overlay

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.chessassistant.ChessApp
import com.chessassistant.R
import com.chessassistant.databinding.OverlayBubbleBinding
import com.chessassistant.databinding.OverlayPanelBinding
import com.chessassistant.engine.ChessEngine
import com.chessassistant.engine.StockfishApiHelper
import com.chessassistant.ui.MainActivity
import kotlinx.coroutines.*

class OverlayService : Service() {

    companion object {
        private const val TAG = "ChessOverlay"
        var isRunning = false
            private set
    }

    private var windowManager: WindowManager? = null
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleBinding: OverlayBubbleBinding? = null
    private var panelBinding: OverlayPanelBinding? = null

    private val engine = ChessEngine()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubbleX = 40
    private var bubbleY = 300
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var initialX = 0
    private var initialY = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            isRunning = true
            // startForeground MUST be called within ~5s of startForegroundService
            startForeground(1, buildNotification())
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

            // Небольшая задержка — MIUI иногда убивает addView сразу после startForeground
            mainHandler.postDelayed({
                safeShowBubble()
            }, 250)
        } catch (e: Exception) {
            Log.e(TAG, "onCreate failed", e)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Sticky — система попробует перезапустить после kill
        return START_STICKY
    }

    // ── Безопасный показ пузыря ───────────────────────────────────────────
    private fun safeShowBubble() {
        try {
            if (!Settings.canDrawOverlays(this)) {
                Log.w(TAG, "No overlay permission")
                Toast.makeText(this, "Нет разрешения «Поверх других окон»", Toast.LENGTH_LONG).show()
                stopSelf()
                return
            }
            if (bubbleView != null) return
            showBubble()
        } catch (e: Exception) {
            Log.e(TAG, "safeShowBubble failed", e)
            Toast.makeText(this, "Ошибка overlay: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun showBubble() {
        val inflater = LayoutInflater.from(this)
        bubbleBinding = OverlayBubbleBinding.inflate(inflater)
        bubbleView = bubbleBinding!!.root

        val params = buildOverlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleX
            y = bubbleY
        }

        bubbleView!!.setOnTouchListener(object : View.OnTouchListener {
            var isDragging = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                try {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            initialX = params.x
                            initialY = params.y
                            initialTouchX = event.rawX
                            initialTouchY = event.rawY
                            isDragging = false
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (event.rawX - initialTouchX).toInt()
                            val dy = (event.rawY - initialTouchY).toInt()
                            if (Math.abs(dx) > 12 || Math.abs(dy) > 12) isDragging = true
                            params.x = initialX + dx
                            params.y = initialY + dy
                            try {
                                windowManager?.updateViewLayout(bubbleView, params)
                            } catch (_: Exception) { }
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!isDragging) {
                                bubbleX = params.x
                                bubbleY = params.y
                                togglePanel()
                            } else {
                                bubbleX = params.x
                                bubbleY = params.y
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "bubble touch error", e)
                }
                return true
            }
        })

        try {
            windowManager?.addView(bubbleView, params)
            Log.i(TAG, "Bubble added")
        } catch (e: Exception) {
            Log.e(TAG, "addView bubble failed", e)
            bubbleView = null
            bubbleBinding = null
            throw e
        }
    }

    // ── Панель ────────────────────────────────────────────────────────────
    private fun togglePanel() {
        try {
            if (panelView != null) dismissPanel() else showPanel()
        } catch (e: Exception) {
            Log.e(TAG, "togglePanel failed", e)
        }
    }

    private fun showPanel() {
        val inflater = LayoutInflater.from(this)
        panelBinding = OverlayPanelBinding.inflate(inflater)
        panelView = panelBinding!!.root

        val width = (resources.displayMetrics.widthPixels * 0.88f).toInt()
        val params = buildOverlayParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 100
        }

        panelBinding!!.btnClose.setOnClickListener { dismissPanel() }
        panelBinding!!.btnAnalyze.setOnClickListener { analyzePosition() }
        panelBinding!!.btnNewGame.setOnClickListener {
            engine.reset()
            updateBoardDisplay()
        }

        panelView!!.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_OUTSIDE) dismissPanel()
            false
        }

        try {
            windowManager?.addView(panelView, params)
            updateBoardDisplay()
        } catch (e: Exception) {
            Log.e(TAG, "addView panel failed", e)
            panelView = null
            panelBinding = null
        }
    }

    private fun dismissPanel() {
        try {
            panelView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) { }
        panelView = null
        panelBinding = null
    }

    private fun analyzePosition() {
        val binding = panelBinding ?: return
        binding.tvSuggestion.text = "Analyzing…"
        binding.tvScore.text = ""
        binding.btnAnalyze.isEnabled = false

        scope.launch {
            try {
                val apiResult = StockfishApiHelper.analyze(engine.getFen())
                if (apiResult.isSuccess) {
                    val r = apiResult.getOrThrow()
                    binding.tvSuggestion.text = r.bestMove
                    binding.tvScore.text = "${StockfishApiHelper.formatScore(r)}  depth ${r.depth}"
                } else {
                    val localMove = withContext(Dispatchers.Default) { engine.getBestMove() }
                    binding.tvSuggestion.text = localMove
                    binding.tvScore.text = "local engine"
                }
            } catch (e: Exception) {
                binding.tvSuggestion.text = "Error"
                binding.tvScore.text = e.message ?: ""
            } finally {
                binding.btnAnalyze.isEnabled = true
            }
        }
    }

    private fun updateBoardDisplay() {
        val binding = panelBinding ?: return
        try {
            binding.tvFen.text = engine.getFen()
            val history = engine.getMoveHistory()
            binding.tvMoves.text = if (history.isEmpty()) "No moves yet"
            else history.mapIndexed { i, m ->
                if (i % 2 == 0) "${i / 2 + 1}. $m" else m
            }.joinToString("  ")
        } catch (_: Exception) { }
    }

    /** Общие безопасные LayoutParams для overlay */
    private fun buildOverlayParams(
        width: Int,
        height: Int,
        extraFlags: Int
    ): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        return WindowManager.LayoutParams(
            width,
            height,
            type,
            extraFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            // MIUI / Android 12+ иногда требуют эти флаги
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, ChessApp.OVERLAY_CHANNEL_ID)
            .setContentTitle("Chess Assistant")
            .setContentText("Overlay active — tap bubble for hints")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        scope.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        try {
            bubbleView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) { }
        try {
            panelView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) { }
        bubbleView = null
        panelView = null
        super.onDestroy()
    }
}
